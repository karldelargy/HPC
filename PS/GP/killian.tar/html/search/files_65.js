var searchData=
[
  ['equations_2ec',['equations.c',['../equations_8c.html',1,'']]],
  ['equations_2eh',['equations.h',['../equations_8h.html',1,'']]]
];
