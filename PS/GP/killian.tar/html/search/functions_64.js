var searchData=
[
  ['dynamic_5falloc_5fmap',['dynamic_alloc_map',['../dataStructiars_8c.html#a32b646293244677533c8e346e68c596f',1,'dynamic_alloc_map(int x, int y):&#160;dataStructiars.c'],['../dataStructiars_8h.html#a32b646293244677533c8e346e68c596f',1,'dynamic_alloc_map(int x, int y):&#160;dataStructiars.c']]]
];
