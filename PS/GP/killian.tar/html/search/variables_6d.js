var searchData=
[
  ['map',['map',['../structmatrix.html#ada95f3c4e6d27e6d2867eed0fad899d1',1,'matrix']]]
];
