var searchData=
[
  ['x',['x',['../structmatrix.html#a8c78cdff42e58de3d2e69de017cc852b',1,'matrix']]]
];
