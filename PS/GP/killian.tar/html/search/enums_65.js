var searchData=
[
  ['enum_5farea',['enum_area',['../dataStructiars_8h.html#a52daafbfcd43fabb6c18219f3950aed9',1,'dataStructiars.h']]]
];
