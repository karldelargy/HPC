var searchData=
[
  ['free_5fmap',['free_map',['../dataStructiars_8c.html#a60fae5d8d4c0bf49776375723b59f6f8',1,'free_map(struct_matrix *gameLand):&#160;dataStructiars.c'],['../dataStructiars_8h.html#a60fae5d8d4c0bf49776375723b59f6f8',1,'free_map(struct_matrix *gameLand):&#160;dataStructiars.c']]]
];
