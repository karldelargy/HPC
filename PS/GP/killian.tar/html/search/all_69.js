var searchData=
[
  ['init_5fmap',['init_map',['../dataStructiars_8c.html#a006bcd38f22095043c8cf2fc3fcb6833',1,'init_map(FILE *fp, struct_matrix *gameLand, configurations configs):&#160;dataStructiars.c'],['../dataStructiars_8h.html#a006bcd38f22095043c8cf2fc3fcb6833',1,'init_map(FILE *fp, struct_matrix *gameLand, configurations configs):&#160;dataStructiars.c']]]
];
