var searchData=
[
  ['printppm',['printPPM',['../printFunctions_8c.html#a863366160c1492f0175e0778884518fa',1,'printPPM(struct_matrix *gameLand, char *hares_directory, char *pumas_directory, char *together_directory, configurations configs):&#160;printFunctions.c'],['../printFunctions_8h.html#a863366160c1492f0175e0778884518fa',1,'printPPM(struct_matrix *gameLand, char *hares_directory, char *pumas_directory, char *together_directory, configurations configs):&#160;printFunctions.c']]]
];
