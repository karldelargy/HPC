var searchData=
[
  ['main',['main',['../predators__main_8c.html#a3c04138a5bfe5d72780bb7e82a18e627',1,'main(int argc, char **argv):&#160;predators_main.c'],['../unit__testing_8c.html#a3c04138a5bfe5d72780bb7e82a18e627',1,'main(int argc, char **argv):&#160;unit_testing.c']]],
  ['mainloop',['mainLoop',['../equations_8c.html#ac54608f72a8b012c1cb7343a5998233a',1,'mainLoop(struct_matrix *gameLand, struct_matrix *newGameLand, double *totalHares, double *totalPumas, configurations configs):&#160;equations.c'],['../equations_8h.html#ac54608f72a8b012c1cb7343a5998233a',1,'mainLoop(struct_matrix *gameLand, struct_matrix *newGameLand, double *totalHares, double *totalPumas, configurations configs):&#160;equations.c']]]
];
