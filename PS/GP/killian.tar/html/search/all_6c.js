var searchData=
[
  ['landneighbourscells',['landNeighboursCells',['../equations_8c.html#a200d4f58e5445c6ebff449896a4e6a92',1,'landNeighboursCells(const struct_matrix *gameLand, int i, int j):&#160;equations.c'],['../equations_8h.html#a200d4f58e5445c6ebff449896a4e6a92',1,'landNeighboursCells(const struct_matrix *gameLand, int i, int j):&#160;equations.c']]]
];
