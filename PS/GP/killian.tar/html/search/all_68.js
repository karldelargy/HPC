var searchData=
[
  ['haresnewvalue',['haresNewValue',['../equations_8c.html#ad5f645a9a8b19333ce88e72b299b5b53',1,'haresNewValue(struct_matrix *gameLand, int i, int j, configurations configs):&#160;equations.c'],['../equations_8h.html#ad5f645a9a8b19333ce88e72b299b5b53',1,'haresNewValue(struct_matrix *gameLand, int i, int j, configurations configs):&#160;equations.c']]]
];
