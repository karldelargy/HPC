var searchData=
[
  ['y',['y',['../structmatrix.html#a6f60f1d85d59d1431d7693f59d7182db',1,'matrix']]]
];
