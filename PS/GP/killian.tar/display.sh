display -sample 200 -delay 1 -resize 250% ./haresPPM/*.ppm &
display -sample 200 -delay 1 -resize 250% ./pumasPPM/*.ppm &
display -sample 200 -delay 1 -resize 250% ./togetherPPM/*.ppm &
